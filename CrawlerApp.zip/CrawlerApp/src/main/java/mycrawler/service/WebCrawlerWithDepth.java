package mycrawler.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import mycrawler.dto.CrawlerElement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
/**
 * 
 * 
 *
 */
public class WebCrawlerWithDepth {
	//just to avoid running the program infinite 
    private static final int MAX_DEPTH = 2;
    
    private HashSet<String> links;
    private HashSet<String> externalLinks;
    private CrawlerElement crawlerElement;


    public WebCrawlerWithDepth() {
        links = new HashSet<>();
        externalLinks = new HashSet<>();
    	crawlerElement = new CrawlerElement();
        crawlerElement.setInternalLinks(new ArrayList<String>());
        crawlerElement.setExternalLinks(new ArrayList<String>());
        
    }

    /**
     * 
     * @param mainUrl
     * @return
     */
    public CrawlerElement getPageLinks(String mainUrl) {
    	if(mainUrl == null || mainUrl.isEmpty()) {
    		return null;
    	}
    	crawlerElement.setLink(mainUrl);
    	getPageLinks(mainUrl, mainUrl, 0);
    	return crawlerElement;
    }
      
    /**
     * 
     * @param mainUrl
     * @param URL
     * @param depth
     */
    public void getPageLinks(String mainUrl, String URL, int depth) {
        if ((!links.contains(URL) && (depth < MAX_DEPTH))) {
            //System.out.println(">> Depth: " + depth + " [" + URL + "]");
            try {
                links.add(URL);
                crawlerElement.getInternalLinks().add(URL);
                
                Document document = Jsoup.connect(URL).validateTLSCertificates(false).get();
                Elements linksOnPage = document.select("a[href]");

                depth++;
                Iterator<Element> iterator = linksOnPage.iterator();
                while (iterator.hasNext()) {
                	Element page = iterator.next();
                	String innerUrl = page.attr("abs:href");
                	if(innerUrl.contains(mainUrl)) {
                		getPageLinks(mainUrl, innerUrl, depth);
                	}
                	else {
                		externalLinks.add(innerUrl);
                        crawlerElement.getExternalLinks().add(innerUrl);
                	}
                }
            } catch (IOException e) {
                System.err.println("For '" + URL + "': " + e.getMessage());
            }
        }
    }
    
//    public void printAll() {
//    	System.out.println("-----------Internal links found-----------");
//        for(String link: links) {
//        	System.out.println(link);
//        }
//    	System.out.println("-----------External links found-----------");
//        for(String link: externalLinks) {
//        	System.out.println(link);
//        }
//    }
//
//    public static void main(String[] args) {
//    	String mainUrl = "https://wiprodigital.com";
//        WebCrawlerWithDepth webCrawlerWithDepth = new WebCrawlerWithDepth();
//        webCrawlerWithDepth.getPageLinks(mainUrl);
//        webCrawlerWithDepth.printAll();
//        
//    }
    
}