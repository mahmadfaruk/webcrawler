package mycrawler.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mycrawler.dto.CrawlerElement;
import mycrawler.service.WebCrawlerWithDepth;

@RestController
public class CrawlerController {

	@RequestMapping("/hello")
	public String hello() {
		return "Hello World RESTful with Spring Boot";
	}

	@RequestMapping("/{uri}/crawl")
	public ResponseEntity<CrawlerElement> crawl(@PathVariable String uri) {
		System.out.println(uri);
		uri ="https://"+uri;
		CrawlerElement cr = new WebCrawlerWithDepth().getPageLinks(uri);
		
		if (cr != null) {
			return new ResponseEntity<CrawlerElement>(cr, HttpStatus.OK);
		} else {		
			return new ResponseEntity<CrawlerElement>(HttpStatus.NOT_FOUND);
		}
	}

}
