package mycrawler.dto;

import java.util.List;

public class CrawlerElement {

	private String link;
	private List<String> internalLinks;
	private List<String> externalLinks;

	public CrawlerElement() {
	}
	
	public String getLink() {
		return link;
	}


	public void setLink(String link) {
		this.link = link;
	}


	public List<String> getInternalLinks() {
		return internalLinks;
	}


	public void setInternalLinks(List<String> internalLinks) {
		this.internalLinks = internalLinks;
	}


	public List<String> getExternalLinks() {
		return externalLinks;
	}


	public void setExternalLinks(List<String> externalLinks) {
		this.externalLinks = externalLinks;
	}

	public CrawlerElement(String link, List<String> internalLinks, List<String> externalLinks) {
		super();
		this.link = link;
		this.internalLinks = internalLinks;
		this.externalLinks = externalLinks;
	}
	




	
	public CrawlerElement(String link) {
		this.link = link;
	}


}
