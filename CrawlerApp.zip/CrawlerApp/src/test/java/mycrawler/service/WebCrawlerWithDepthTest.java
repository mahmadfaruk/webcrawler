package mycrawler.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Iterator;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import mycrawler.dto.CrawlerElement;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Jsoup.class)
public class WebCrawlerWithDepthTest {

	public static final String URL = "https://google.com";
	public static final String URL_INNER = "https://facebook.com/images";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInvalidInput() {
		Assert.assertNull(new WebCrawlerWithDepth().getPageLinks(null));
		Assert.assertNull(new WebCrawlerWithDepth().getPageLinks(""));
	}
	
	@Test
	public void testValidInput() throws IOException {
		//Jsoup test = mock(Jsoup.class);
        PowerMockito.mockStatic(Jsoup.class);

		Connection conn = mock(Connection.class);
		Document doc = mock(Document.class);
		Element element = mock(Element.class);
		Elements elements = mock(Elements.class);

        BDDMockito.given(Jsoup.connect(URL)).willReturn(conn);

		//when(test.connect(URL)).thenReturn(conn);
		when(conn.validateTLSCertificates(false)).thenReturn(conn);
		when(conn.get()).thenReturn(doc);
		when(doc.select(anyString())).thenReturn(elements);
		
		Iterator<Element> i= mock(Iterator.class);
		when(elements.iterator()).thenReturn(i);
        when(i.next()).thenReturn(element);
        when(i.hasNext()).thenReturn(Boolean.TRUE, Boolean.FALSE);

        when(element.attr(anyString())).thenReturn(URL_INNER);
		
        WebCrawlerWithDepth crawler = new WebCrawlerWithDepth();
        CrawlerElement pageLinks = crawler.getPageLinks(URL);
        //System.out.println(pageLinks);
        Assert.assertTrue(URL_INNER, pageLinks.getExternalLinks().contains(URL_INNER));
        Assert.assertTrue(URL, pageLinks.getInternalLinks().contains(URL));

        
	}

}
